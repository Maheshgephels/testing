import React, { useState, useEffect, Fragment } from 'react';
import { Container, Row, Col, Card, CardHeader, CardBody, Button, Table, Input, TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap';
import classnames from 'classnames';
import { Breadcrumbs } from '../../AbstractElements';
import Papa from 'papaparse';
import axios from 'axios';
import { BackendAPI } from '../../api';
import SweetAlert from 'sweetalert2';
import { Link, useNavigate } from 'react-router-dom';
import { getToken } from '../../Auth/Auth';
import useAuth from '../../Auth/protectedAuth';
import { toast } from 'react-toastify';


const ImportUserWithoutReg = () => {
    useAuth();
    const [importedData, setImportedData] = useState([]);
    const [duplicateEntries, setDuplicateEntries] = useState([]);
    const [wrongEntries, setWrongEntries] = useState([]); // State for wrong entries
    const [activeTab, setActiveTab] = useState('1');
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [maxNumber, setMaxNumber] = useState(0); // State for maximum registration number
    const [catid, setCatid] = useState([]);
    const [workshopid, setWorkshopid] = useState([]);
    const [manData, setManData] = useState([]);
    const [fileData, setfileData] = useState([]);
    const [importingData, setImportingData] = useState(false);

    console.log("File data:", fileData);
    console.log("Mandatory Data:", manData);
    console.log("Workshop data:", workshopid);
    console.log("Correct Entries:", importedData);
    console.log("Duplicate Entries:", duplicateEntries);
    console.log("Wrong Entries:", wrongEntries);

    const navigate = useNavigate(); // Initialize useHistory

    useEffect(() => {
        // Fetch the maximum registration number when the component mounts
        fetchMaxNumber();
    }, []);

    const fetchMaxNumber = async () => {
        try {
            const token = getToken();
            const response = await axios.get(`${BackendAPI}/manageuser/getMaxNo`, {
                headers: {
                    Authorization: `Bearer ${token}` // Include the token in the Authorization header
                }
            });
            const maxNo = response.data; // Response directly contains the maximum registration number
            setMaxNumber(maxNo);
        } catch (error) {
            console.error('Error fetching maximum registration number:', error);
        }
    };

    useEffect(() => {
        const fetchCatId = async () => {
            setLoading(true);
            try {
                const token = getToken();
                const response = await axios.get(`${BackendAPI}/field/getCatId`, {
                    headers: {
                        Authorization: `Bearer ${token}` // Include the token in the Authorization header
                    }
                });
                setCatid(response.data.catData);
                setWorkshopid(response.data.workshopData);

                // Transform the mandatory data to an array of field labels
                const mandatoryLabels = response.data.mandatoryData.map(item => item.cs_field_label);
                setManData(mandatoryLabels);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching users:", error);
                setLoading(false);
            }
        };

        fetchCatId();
    }, []);

    const toggleTab = (tab) => {
        if (activeTab !== tab) setActiveTab(tab);
    };

    const handleFileSelect = (event) => {
        const selectedFile = event.target.files[0];
        if (selectedFile) {
            const fileType = selectedFile.type;
            if (fileType !== 'text/csv') {
                SweetAlert.fire({
                    title: 'Warning!',
                    text: 'Select correct format',
                    icon: 'warning',
                    timer: 3000,
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                });
                // Clear the file input
                event.target.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const data = new Uint8Array(e.target.result);
                if (fileType === 'text/csv') {
                    Papa.parse(selectedFile, {
                        complete: (result) => {
                            const fileData = result.data;
                            processFileData(fileData);
                        },
                        header: true
                    });
                }
                // Clear the file input after processing
                event.target.value = '';
            };
            reader.readAsArrayBuffer(selectedFile);
        }
    };

    const processFileData = (fileData) => {
        // Extract headers from the first row of the CSV file
        const csvHeaders = fileData.length > 0 ? Object.keys(fileData[0]).map(header => header.trim()) : [];
        console.log("CSV Headers:", csvHeaders);

        // Find matching headers
        const matchingHeaders = csvHeaders.filter(header => manData.includes(header));

        // Log matched headers to the console
        console.log("Matched Headers:", matchingHeaders);

        // Check if 'Registration Category ID' and 'Registration Number' are in the header
        const hasRegistrationCategoryIDHeader = csvHeaders.includes('Registration Category ID');
        const hasRegistrationNumberHeader = csvHeaders.includes('Registration Number');

        if (!hasRegistrationCategoryIDHeader) {
            toast('File must contain Registration Category ID column');
            setWrongEntries(fileData);
            setImportedData([]);
            return;
        }

        if (hasRegistrationNumberHeader) {
            toast.warning('File contains Registration Number column');
            setWrongEntries(fileData);
            setImportedData([]);
            return;
        }

        // Existing logic
        const fileCatids = fileData
            .map((item) => String(item['Registration Category ID']))
            .filter(Boolean); // Filter out undefined and null values

        const fileWorkshopids = fileData
            .map((item) => String(item['Workshop Category']))
            .filter(Boolean); // Filter out undefined and null values

        const activeCatid = catid.map((Cat) => String(Cat.cs_reg_cat_id));
        const activeWorkshopid = workshopid.map((Workshop) => String(Workshop.cs_workshop_id));

        const wrongs = fileCatids.filter(
            (catid) => !activeCatid.includes(catid)
        );

        const wrongWorkshops = fileWorkshopids.filter(
            (workshopid) => !activeWorkshopid.includes(workshopid)
        );

        // Check for empty columns in matched headers
        const emptyEntries = fileData.filter((item) =>
            matchingHeaders.some((header) => item[header] === undefined || item[header].trim() === '')
        );

        // Validation logic for First Name and Last Name
        const invalidEntries = fileData.filter((item) => {
            const firstName = item['First Name'] ? item['First Name'].trim() : '';
            const lastName = item['Last Name'] ? item['Last Name'].trim() : '';

            const hasLeadingOrTrailingSpaces = (value) => /^\s+|\s+$/.test(value);
            const hasInvalidChars = (value) => !/^[a-zA-Z0-9-_()]+(?: [a-zA-Z0-9-_()]+)*$/.test(value);

            return (
                hasLeadingOrTrailingSpaces(firstName) ||
                hasLeadingOrTrailingSpaces(lastName) ||
                hasInvalidChars(firstName) ||
                hasInvalidChars(lastName)
            );
        });

        const wrongEntries = fileData.filter((item) =>
            (item['Registration Category ID'] && wrongs.includes(String(item['Registration Category ID']))) ||
            (item['Workshop Category'] && wrongWorkshops.includes(String(item['Workshop Category']))) ||
            emptyEntries.includes(item) ||
            invalidEntries.includes(item)
        );

        setWrongEntries(wrongEntries);

        const correctEntries = fileData.filter((item) =>
            (item['Registration Category ID'] && !wrongs.includes(String(item['Registration Category ID']))) &&
            (item['Workshop Category'] && !wrongWorkshops.includes(String(item['Workshop Category']))) &&
            !emptyEntries.includes(item) &&
            !invalidEntries.includes(item)
        );

        setImportedData(correctEntries);
        setfileData(fileData);

        // Show success alert
        SweetAlert.fire({
            title: 'Success!',
            text: 'File Uploaded successfully!',
            icon: 'success',
            timer: 3000,
            showConfirmButton: false,
            allowOutsideClick: false,
            allowEscapeKey: false,
        });
    };


    const findDuplicates = (data) => {
        const duplicates = [];
        const headers = Object.keys(data[0]); // Assuming headers are in the first row

        // Find the index of the "Registration Number" column
        const registrationNumberIndex = headers.findIndex(header => header === "Registration Number");

        if (registrationNumberIndex !== -1) {
            const seen = {};
            data.forEach((entry, index) => {
                const value = entry[headers[registrationNumberIndex]];
                if (seen[value]) {
                    duplicates.push(entry);
                } else {
                    seen[value] = true;
                }
            });
        } else {
            console.error("Registration Number column not found.");
        }
        setDuplicateEntries(duplicates);
    };




    const handleImportCorrectedData = async () => {
        try {

            setImportingData(true); // Start importing process

            // Filter out wrong entries and duplicate entries
            const uniqueCorrectedData = importedData.filter(entry => {
                return entry && entry['First Name'] && entry['First Name'].trim() !== '';
            });

            console.log("Unique Corrected Data:", uniqueCorrectedData);
            const chunkSize = 100; // Define the size of each chunk
            const token = getToken();

            // Function to send data in chunks
            const sendChunk = async (chunk) => {
                try {
                    await axios.post(`${BackendAPI}/manageuser/addBulkUser`, chunk, {
                        headers: {
                            Authorization: `Bearer ${token}` // Include the token in the Authorization header
                        }
                    });
                } catch (error) {
                    console.error('Error sending chunk:', error.response ? error.response.data : error.message);
                    throw error; // Rethrow the error to handle it in the outer try-catch block
                }
            };

            // Split the data into chunks and send each chunk
            for (let i = 0; i < uniqueCorrectedData.length; i += chunkSize) {
                const chunk = uniqueCorrectedData.slice(i, i + chunkSize);
                await sendChunk(chunk); // Wait for the request to complete before sending the next one
            }
            // const token = getToken();
            // await axios.post(`${BackendAPI}/manageuser/addBulkUser`, uniqueCorrectedData, {
            //     headers: {
            //         Authorization: `Bearer ${token}` // Include the token in the Authorization header
            //     }
            // });

            SweetAlert.fire({
                title: 'Success!',
                text: 'User correct data imported successfully !',
                icon: 'success',
                timer: 3000,
                showConfirmButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.dismiss === SweetAlert.DismissReason.timer) {
                    navigate(`${process.env.PUBLIC_URL}/User-listing/Consoft`);
                }
            });
        } catch (error) {
            console.error('Error Importing:', error.message);
        } finally {
            setImportingData(false); // Finished importing process
        }
    };

    const handleDownloadSampleFile = async () => {
        try {
            // Make a GET request to the sample file route
            console.log("hello");
            const response = await axios.get(`${BackendAPI}/report/samplefile`, {
                responseType: 'blob' // Specify responseType as 'blob' to handle binary data
            });

            // Create a URL for the generated file blob
            const url = window.URL.createObjectURL(new Blob([response.data]));

            // Create an anchor element and trigger a download
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'sample_without_registration_num.csv');
            document.body.appendChild(link);
            link.click();

            // Cleanup
            link.parentNode.removeChild(link);
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Error downloading sample file:', error);
        }
    };


    return (
        <Fragment>
            <Breadcrumbs mainTitle="Import Users" parent="Manage User" title="Import Users" />
            <Container fluid>

                <Row>
                    <Col sm="12">
                        <Card>
                            <CardHeader className="d-flex justify-content-between align-items-center flex-column flex-md-row">
                                <div className="mb-2 mb-md-0">
                                    <h5 className="mb-2 text-start">Import without Registration Number</h5>
                                    <small>Your auto registration number will start from: {maxNumber}</small>
                                </div>
                                <div className="mb-2 mt-md-0">
                                    <button onClick={handleDownloadSampleFile} className="btn btn-success">
                                        Sample File
                                    </button>
                                </div>

                                <div className="mt-2 mt-md-0">
                                    <Input
                                        type="file"
                                        accept=".csv,.xlsx"
                                        onChange={handleFileSelect}
                                        style={{ display: 'none' }}
                                        id="fileInput"
                                    />
                                    <label htmlFor="fileInput" className="btn btn-primary">Select File</label>
                                </div>

                                <div className=" mt-md-0">
                                    <Button
                                        color='warning'
                                        type='button'
                                        className="mr-2 mb-2"
                                        onClick={handleImportCorrectedData}
                                        disabled={importedData.length === 0 || importingData} // Disable button if no imported data or importing in progress
                                    >
                                        Import Data
                                    </Button>
                                </div>



                            </CardHeader>
                            <CardBody>
                                <div className='table-responsive'>

                                    <Nav tabs>
                                        <NavItem>
                                            <NavLink
                                                className={classnames({ active: activeTab === '1' })}
                                                onClick={() => { toggleTab('1'); }}
                                                style={{ cursor: 'pointer' }}
                                            >
                                                Correct Entries
                                            </NavLink>
                                        </NavItem>
                                        <NavItem>
                                            <NavLink
                                                className={classnames({ active: activeTab === '2' })}
                                                onClick={() => { toggleTab('2'); }}
                                                style={{ cursor: 'pointer' }}
                                            >
                                                Duplicate Entries
                                            </NavLink>
                                        </NavItem>
                                        <NavItem>
                                            <NavLink
                                                className={classnames({ active: activeTab === '3' })}
                                                onClick={() => { toggleTab('3'); }}
                                                style={{ cursor: 'pointer' }}
                                            >
                                                Wrong Entries
                                            </NavLink>
                                        </NavItem>
                                    </Nav>
                                    <TabContent activeTab={activeTab}>
                                        <TabPane tabId="1">
                                            <Table>
                                                <thead>
                                                    <tr>
                                                        {fileData.length > 0 &&
                                                            Object.keys(fileData[0]).map((header, index) => (
                                                                <th key={index}>{header}</th>
                                                            ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {importedData.length > 0 ? (
                                                        importedData.map((rowData, rowIndex) => (
                                                            <tr key={rowIndex}>
                                                                {Object.values(rowData).map((value, colIndex) => (
                                                                    <td key={colIndex}>{value}</td>
                                                                ))}
                                                            </tr>
                                                        ))
                                                    ) : (
                                                        <tr>
                                                            <td colSpan={fileData.length > 0 ? Object.keys(fileData[0]).length : 1} className="text-center">
                                                                No Correct Entries Found
                                                            </td>
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </Table>
                                        </TabPane>
                                        <TabPane tabId="2">
                                            <Table>
                                                <thead>
                                                    <tr>
                                                        {fileData.length > 0 &&
                                                            Object.keys(fileData[0]).map((header, index) => (
                                                                <th key={index}>{header}</th>
                                                            ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {duplicateEntries.length > 0 ? (
                                                        duplicateEntries.map((rowData, rowIndex) => (
                                                            <tr key={rowIndex}>
                                                                {Object.values(rowData).map((value, colIndex) => (
                                                                    <td key={colIndex}>{value}</td>
                                                                ))}
                                                            </tr>
                                                        ))
                                                    ) : (
                                                        <tr>
                                                            <td colSpan={fileData.length > 0 ? Object.keys(fileData[0]).length : 1} className="text-center">
                                                                No Duplicate Entries Found
                                                            </td>
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </Table>
                                        </TabPane>
                                        <TabPane tabId="3">
                                            <Table>
                                                <thead>
                                                    <tr>
                                                        {fileData.length > 0 &&
                                                            Object.keys(fileData[0]).map((header, index) => (
                                                                <th key={index}>{header}</th>
                                                            ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {wrongEntries.length > 0 ? (
                                                        wrongEntries.map((rowData, rowIndex) => (
                                                            <tr key={rowIndex}>
                                                                {Object.values(rowData).map((value, colIndex) => (
                                                                    <td key={colIndex}>{value}</td>
                                                                ))}
                                                            </tr>
                                                        ))
                                                    ) : (
                                                        <tr>
                                                            <td colSpan={fileData.length > 0 ? Object.keys(fileData[0]).length : 1} className="text-center">
                                                                No Wrong Entries Found
                                                            </td>
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </Table>
                                        </TabPane>
                                    </TabContent>
                                </div>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </Fragment>
    );
};

export default ImportUserWithoutReg;
