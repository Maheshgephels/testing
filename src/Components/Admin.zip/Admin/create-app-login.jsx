import React, { Fragment, useState, useEffect } from 'react';
import { Container, Row, Col, Button, Card, CardBody, Modal, ModalHeader, ModalBody, ModalFooter, FormFeedback, Label } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import axios from 'axios';
import { BackendAPI } from '../../api';
import SweetAlert from 'sweetalert2';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { IoIosArrowDown } from "react-icons/io";
import { Field, Form } from 'react-final-form'; // Import Field and Form from react-final-form
import { Link, useNavigate } from 'react-router-dom';
import Select from 'react-select';
import { required, email, name, password, expiryDate } from '../Utils/validationUtils';


//Utility function used to combine multiple validation functions into a single validation function
const composeValidators = (...validators) => value =>
    validators.reduce((error, validator) => error || validator(value), undefined);

const CreateAppLogin = () => {
    const [data, setData] = useState([]);
    const navigate = useNavigate(); // Initialize useHistory
    const [loading, setLoading] = useState(true);
    const [modal, setModal] = useState(false);
    const initialValue = '';
    const [showPassword, setShowPassword] = useState(false);

    useEffect(() => {
        fetchFacilityType(); // Corrected function name
    }, []);

    const fetchFacilityType = async () => {
        try {
            const response = await axios.get(`${BackendAPI}/role/getroles`);
            setData(response.data);
            setLoading(false);
            console.log('Facility Types:', response.data); // Log the data received from the API
        } catch (error) {
            console.error('Error fetching facility types:', error);
            setLoading(false);
        }
    };

    const role = [...new Set(data.map(item => ({ value: item.cs_role_id, label: item.cs_role_name })))];

    const handleSelect = (event) => {
        console.log(event.target.value);
    }

    const onSubmit = async (values) => {
        try {
            console.log('Form data to send:', values);
            await axios.post(`${BackendAPI}/user/storeappuserlogin`, values);

            SweetAlert.fire({
                title: 'Success!',
                text: 'User login created successfully!',
                icon: 'success',
                timer: 3000,
                showConfirmButton: false
            }).then((result) => {
                if (result.dismiss === SweetAlert.DismissReason.timer) {
                    navigate("/App-user/Consoft");
                }
            });
        } catch (error) {
            console.error('Error creating application login:', error.message);
        }
    };

    const handleCancel = () => {
        setModal(true);
    };

    return (
        <Fragment>
            <Breadcrumbs mainTitle="Create App User" parent="App User Login" title="Create App User" />
            <Container fluid={true}>
                <Row>
                    <Col sm="12">
                        <Card>
                            <CardBody>
                                <Form onSubmit={onSubmit}>
                                    {({ handleSubmit }) => (
                                        <form className='needs-validation' noValidate='' onSubmit={handleSubmit}>
                                            {/* Your form fields */}
                                            <Row>
                                                <Col md='4 mb-3'>
                                                    <Field
                                                        name="uName"
                                                        validate={composeValidators(required, name)}
                                                    >
                                                        {({ input, meta }) => (
                                                            <div>

                                                                <Label className='form-label' for="displayname"><strong>User Name *</strong></Label>
                                                                <input
                                                                    {...input}
                                                                    className="form-control"
                                                                    id="displayname"
                                                                    type="text"
                                                                    placeholder="Enter User name"
                                                                />
                                                                {meta.error && meta.touched && <FormFeedback className='d-block text-danger'>{meta.error}</FormFeedback>}
                                                            </div>
                                                        )}
                                                    </Field>
                                                </Col>

                                                <Col md='4' className='mb-3'>
                                                    <Field
                                                        name="pass"
                                                        validate={composeValidators(required, password)}
                                                    >
                                                        {({ input, meta }) => (
                                                            <div>
                                                                <Label className='form-label' for="password"><strong>Password *</strong></Label>
                                                                <div className="input-group">
                                                                    <input
                                                                        {...input}
                                                                        className="form-control"
                                                                        id="password"
                                                                        type={showPassword ? "text" : "password"}
                                                                        placeholder="Enter Password"
                                                                    />
                                                                    <button
                                                                        className="btn btn-outline-dark"
                                                                        type="button"
                                                                        onClick={() => setShowPassword(!showPassword)}
                                                                    >
                                                                        {showPassword ? <FaEyeSlash /> : <FaEye />}
                                                                    </button>
                                                                </div>
                                                                {meta.error && meta.touched && <FormFeedback className='d-block text-danger'>{meta.error}</FormFeedback>}
                                                            </div>
                                                        )}
                                                    </Field>
                                                </Col>

                                            </Row>

                                            <Row>
                                                <Col md='4 mb-3'>
                                                    <Field
                                                        name="email"
                                                        validate={composeValidators(required, email)}
                                                    >
                                                        {({ input, meta }) => (
                                                            <div>

                                                                <Label className='form-label' for="email"><strong>User Name *</strong></Label>
                                                                <input
                                                                    {...input}
                                                                    className="form-control"
                                                                    id="email"
                                                                    type="text"
                                                                    placeholder="Enter Email"
                                                                />
                                                                {meta.error && meta.touched && <FormFeedback className='d-block text-danger'>{meta.error}</FormFeedback>}
                                                            </div>
                                                        )}
                                                    </Field>
                                                </Col>

                                                <Col md="4" className="mb-3">
                                                    <Label className='form-label' for="type"><strong>Role Name *</strong></Label>
                                                    <Field
                                                        name="roleid"
                                                        validate={required}
                                                    >
                                                        {({ input, meta }) => (
                                                            <div>
                                                                <select
                                                                    {...input}
                                                                    className="form-control"
                                                                    id="selectmethod"
                                                                >
                                                                    <option value="">Select Role</option>
                                                                    {role.map((option) => (
                                                                        <option key={option.value} value={option.value}>
                                                                            {option.label}
                                                                        </option>
                                                                    ))}
                                                                </select>
                                                                {/* <button type="button"
                                                                >
                                                                    <IoIosArrowDown />

                                                                </button> */}
                                                                {meta.error && meta.touched && <FormFeedback className='d-block text-danger'>{meta.error}</FormFeedback>}
                                                                <div className='valid-feedback'>Looks good!</div>
                                                            </div>
                                                        )}
                                                    </Field>
                                                </Col>

                                            </Row>

                                            <Row>
                                                <Col md='4 mb-3'>
                                                    <Field
                                                        name="expiry"
                                                        validate={composeValidators(expiryDate)}
                                                    >
                                                        {({ input, meta }) => (
                                                            <div>

                                                                <Label className='form-label' for='expiry_date'><strong> Login Expiry Date * </strong></Label>
                                                                <input
                                                                    {...input}
                                                                    className="form-control"
                                                                    id="expiry_date"
                                                                    type="date"
                                                                    placeholder="Enter Expiry Date"
                                                                    min={new Date().toISOString().split('T')[0]}
                                                                />
                                                                {meta.error && meta.touched && <FormFeedback className='d-block text-danger'>{meta.error}</FormFeedback>}
                                                            </div>
                                                        )}
                                                    </Field>
                                                </Col>

                                            </Row>


                                            <div>
                                                <Button color='primary' type='submit' className="mr-2 mt-3">Create App Login</Button>
                                                <Button color='warning' onClick={handleCancel} className="mt-3">Cancel</Button>
                                            </div>



                                            {/* Repeat the above pattern for other fields */}
                                            {/* Add submit and cancel buttons */}
                                        </form>
                                    )}
                                </Form>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
            {/* Modal */}
            <Modal isOpen={modal} toggle={() => setModal(!modal)} centered>
                <ModalHeader toggle={() => setModal(!modal)}>Confirm Cancel</ModalHeader>
                <ModalBody>
                    Your changes will be discarded. Are you sure you want to cancel?
                </ModalBody>
                <ModalFooter>
                    <Link to="/App-user/Consoft" className="btn btn-warning">Yes</Link>
                    <Button color="primary" onClick={() => setModal(!modal)}>No</Button>
                </ModalFooter>
            </Modal>
        </Fragment>
    );
};

export default CreateAppLogin;
