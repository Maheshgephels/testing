import React, { Fragment, useEffect, useState } from 'react';
import { Container, Row, Col, Card, Table, CardHeader, Button, CardBody, Input, Label } from 'reactstrap';
import { Breadcrumbs } from '../../AbstractElements';
import { Link } from 'react-router-dom';
import { FaEdit, FaTrash, FaEye, FaEyeSlash } from 'react-icons/fa'; // Import the eye icons
import { GoDotFill } from "react-icons/go";
import { TbLogout } from "react-icons/tb";
import SweetAlert from 'sweetalert2';
import axios from 'axios';
import { BackendAPI } from '../../api';
import { Pagination, Select } from 'antd';

const { Option } = Select;

const AppUser = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [pageSize, setPageSize] = useState(10);
    const [totalItems, setTotalItems] = useState(0);
    const [searchText, setSearchText] = useState('');
    const [showPassword, setShowPassword] = useState({});

    useEffect(() => {
        fetchUsers();
    }, [currentPage, pageSize, searchText]);

    const fetchUsers = async () => {
        try {
            const response = await axios.get(`${BackendAPI}/user/getappuserlogin?page=${currentPage}&pageSize=${pageSize}&search=${searchText}`);
            setData(response.data.facilities);
            setTotalPages(response.data.totalPages);
            setTotalItems(response.data.totalItems);
            setLoading(false);

            // Initialize showPassword state for each item
            const initialShowPasswordState = response.data.facilities.reduce((acc, item) => {
                acc[item.id] = false;
                return acc;
            }, {});
            setShowPassword(initialShowPasswordState);
        } catch (error) {
            console.error('Error fetching users:', error);
            setLoading(false);
        }
    };

    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    const handlePageSizeChange = (size) => {
        setPageSize(size);
        setCurrentPage(1);
    };

    const handleSearch = (value) => {
        setSearchText(value);
        setCurrentPage(1);
    };

    const formatLastLogin = (lastLogin) => {
        if (!lastLogin) return ''; // Handle case when last login is not provided
        const date = new Date(lastLogin);
        const options = {
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false // Use 24-hour format
        };
        return date.toLocaleString(undefined, options); // Format the date and time
    };

    const toggleShowPassword = (id) => {
        setShowPassword(prevState => ({
            ...prevState,
            [id]: !prevState[id]
        }));
    };

    const handleDelete = async (id) => {
        try {
            // Make an API request to delete the item with the given ID
            await axios.delete(`${BackendAPI}/user/RemoveAppUser/${id}`);
            // Remove the deleted item from the data array
            setData(prevData => prevData.filter(item => item.id !== id));
            // Update total items count
            setTotalItems(prevTotalItems => prevTotalItems - 1);
            SweetAlert.fire({
                title: 'Warning!',
                text: 'User login deleted successfully!',
                icon: 'warning',
                timer: 3000,
                showConfirmButton: false
            });
        } catch (error) {
            console.error('Error deleting user:', error.message);
        }
    };
    

    return (
        <Fragment>
            <Breadcrumbs mainTitle="App User Login" parent="Onsite App" title="App User Login" />
            <Container fluid={true}>
                <Row>
                    <Col sm="12">
                        <Card>
                            <CardHeader className="d-flex justify-content-between align-items-center flex-column flex-md-row">
                                <div className="mb-2 mb-md-0">
                                    <h5 className="mb-2 text-center">App User Logins</h5>
                                    <Input
                                        placeholder="Search all columns"
                                        onChange={(e) => handleSearch(e.target.value)}
                                        style={{ width: 200 }}
                                    />
                                </div>
                                <div className="mt-2 mt-md-0">
                                    <Link to="/create-app-login/Consoft" className="btn btn-warning">Create App Login</Link>
                                </div>
                            </CardHeader>
                            <CardBody>
                                <div className='table-responsive'>
                                    {loading ? (
                                        <p>Loading...</p>
                                    ) : (
                                        <Table>
                                            {/* Table Header */}
                                            <thead>
                                                <tr className='border-bottom-primary'>
                                                    <th scope='col'>{'Sr No.'}</th>
                                                    <th scope='col'>{'Username'}</th>
                                                    <th scope='col'>{'Password'}</th>
                                                    <th scope='col'>{'Email'}</th>
                                                    <th scope='col'>{'Role'}</th>
                                                    <th scope='col'>{'Device Id'}</th>
                                                    <th scope='col' className="text-center">{'Last Login'}</th>
                                                    <th scope='col'>{'Login Expiry'}</th>
                                                    <th scope='col'>{'Login Status'}</th>
                                                    <th scope='col'>{'Status'}</th>
                                                    <th scope='col' className="text-center">{'Action'}</th>
                                                </tr>
                                            </thead>
                                            {/* Table Body */}
                                            <tbody>
                                                {data.map((item, index) => (
                                                    <tr key={index} className="border-bottom-primary">
                                                        <td>{item.id}</td>
                                                        <td>{item.cs_username}</td>
                                                        <td>
                                                            {showPassword[item.id] ? item.cs_password : '********'}
                                                            <Button color="link" onClick={() => toggleShowPassword(item.id)}>
                                                                {showPassword[item.id] ? <FaEyeSlash /> : <FaEye />}
                                                            </Button>
                                                        </td>
                                                        <td>{item.cs_email}</td>
                                                        <td>{item.cs_role_name}</td>
                                                        <td>{item.logged_in_device_id}</td>
                                                        <td className="text-center">{formatLastLogin(item.cs_created_at)}</td>
                                                        <td>{item.cs_valid_upto}</td>
                                                        <td className="text-center">
                                                            {item.logged_in_device_id !== null && item.logged_in_device_id !== '' ? (
                                                                <Label className="text-success">Log In</Label>
                                                            ) : (
                                                                <Label className="text-danger">Log Out</Label>
                                                            )}
                                                        </td>
                                                        <td className="text-center">
                                                            {item.cs_status === '0' ? (
                                                                <span style={{ color: 'green', fontSize: '20px' }}>
                                                                    <GoDotFill />
                                                                </span>
                                                            ) : (
                                                                <span style={{ color: 'red', fontSize: '20px' }}>
                                                                    <GoDotFill />
                                                                </span>
                                                            )}
                                                        </td>
                                                        <td>
                                                            <Button color="primary" size="sm">
                                                                <FaEdit />
                                                            </Button>
                                                            <Button color="danger" size="sm" onClick={() => handleDelete(item.id)}>
                                                                <FaTrash />
                                                            </Button>
                                                            <Button color="warning" size="sm"><TbLogout /></Button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </Table>
                                    )}
                                </div>
                                {/* Pagination */}
                                <div className="d-flex justify-content-between align-items-center mt-3" >
                                    <Pagination
                                        onChange={handlePageChange}
                                        defaultCurrent={currentPage}
                                        total={totalItems}
                                        pageSize={pageSize}
                                    />
                                    <Select
                                        defaultValue={10}
                                        onChange={handlePageSizeChange}
                                        style={{ width: 60 }}
                                    >
                                        <Option value={10}>10</Option>
                                        <Option value={20}>20</Option>
                                        <Option value={30}>30</Option>
                                    </Select>
                                </div>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </Fragment>
    );
};

export default AppUser;
